const User = require("../models/User");
const Listing = require("../models/Listing");
const mongoose = require("mongoose");

module.exports.renderRegister = (req, res) => {
  res.render("users/register.ejs");
};

module.exports.register = async (req, res, next) => {
  try {
    const { username, email, password, fullName, isHost } = req.body;
    let avatarUrl = "";
    if (req.file) {
      avatarUrl = `/uploads/${req.file.filename}`;
    }

    const newUser = new User({
      email,
      username,
      fullName: fullName || username,
      avatar: avatarUrl,
      isHost: isHost === "on" || isHost === "true",
    });

    const registeredUser = await User.register(newUser, password);
    req.login(registeredUser, (err) => {
      if (err) return next(err);
      req.flash("success", `Welcome to Reservoir, ${registeredUser.fullName || registeredUser.username}! Your account has been created.`);
      const redirectUrl = res.locals.redirectUrl || "/listings";
      delete req.session.redirectUrl;
      req.session.save((saveErr) => {
        if (saveErr) return next(saveErr);
        res.redirect(redirectUrl);
      });
    });
  } catch (e) {
    req.flash("error", e.message);
    res.redirect("/register");
  }
};

module.exports.renderLogin = (req, res) => {
  res.render("users/login.ejs");
};

module.exports.login = async (req, res, next) => {
  const displayName = req.user.fullName || req.user.username;
  req.flash("success", `Welcome back, ${displayName}!`);
  let redirectUrl = res.locals.redirectUrl || "/listings";
  if (redirectUrl === "/login" || redirectUrl === "/register") {
    redirectUrl = "/listings";
  }
  delete req.session.redirectUrl;
  req.session.save((err) => {
    if (err) return next(err);
    res.redirect(redirectUrl);
  });
};

module.exports.logout = (req, res, next) => {
  req.logout((err) => {
    if (err) return next(err);
    req.flash("success", "You have successfully logged out.");
    req.session.save((saveErr) => {
      if (saveErr) return next(saveErr);
      res.redirect("/listings");
    });
  });
};

module.exports.renderProfile = async (req, res) => {
  if (mongoose.connection.readyState < 1) {
    return res.render("users/profile.ejs", { user: req.user || {} });
  }
  const user = await User.findById(req.user._id);
  res.render("users/profile.ejs", { user: user || req.user });
};

module.exports.updateProfile = async (req, res) => {
  if (mongoose.connection.readyState < 1) {
    req.flash("error", "Database is offline. Profile changes cannot be saved.");
    return res.redirect("/profile");
  }
  const { fullName, email, avatarUrl, isHost } = req.body;
  const user = await User.findById(req.user._id);
  
  if (fullName) user.fullName = fullName.trim();
  if (email) user.email = email.trim();
  if (req.file) {
    user.avatar = `/uploads/${req.file.filename}`;
  } else if (avatarUrl && avatarUrl.trim() !== "") {
    user.avatar = avatarUrl.trim();
  }
  user.isHost = isHost === "on" || isHost === "true";

  await user.save();
  req.flash("success", "Account profile details and customer profile picture updated successfully!");
  req.session.save(() => {
    res.redirect("/profile");
  });
};

module.exports.renderFavorites = async (req, res) => {
  if (mongoose.connection.readyState < 1) {
    return res.render("users/favorites.ejs", { favorites: [] });
  }
  const user = await User.findById(req.user._id).populate("favorites");
  res.render("users/favorites.ejs", { favorites: user ? user.favorites || [] : [] });
};

module.exports.toggleFavorite = async (req, res) => {
  const { id } = req.params;
  const user = await User.findById(req.user._id);
  
  const index = user.favorites.indexOf(id);
  let isFavorite = false;
  
  if (index === -1) {
    user.favorites.push(id);
    isFavorite = true;
  } else {
    user.favorites.splice(index, 1);
    isFavorite = false;
  }

  await user.save();

  if (req.xhr || req.headers.accept.indexOf("json") > -1) {
    return res.json({ success: true, isFavorite });
  }

  req.flash("success", isFavorite ? "Property added to your Favourites!" : "Property removed from Favourites.");
  res.redirect(req.get("referer") || "/favorites");
};


