const Booking = require("../models/Booking");
const Listing = require("../models/Listing");
const sampleListings = require("../seed/sampleListings");
const mongoose = require("mongoose");

module.exports.createBooking = async (req, res) => {
  const { id } = req.params;
  const { checkIn, checkOut, guests } = req.body;

  let listing = null;
  try {
    if (mongoose.connection.readyState >= 1 && mongoose.Types.ObjectId.isValid(id)) {
      listing = await Listing.findById(id);
    }
  } catch (err) {
    listing = null;
  }

  if (!listing) {
    listing = sampleListings.find(s => s._id && s._id.toString() === id.toString());
  }

  if (!listing) {
    req.flash("error", "Listing not found!");
    return res.redirect("/listings");
  }

  const start = new Date(checkIn);
  const end = new Date(checkOut);

  if (isNaN(start.getTime()) || isNaN(end.getTime()) || end <= start) {
    req.flash("error", "Please select valid check-in and check-out dates.");
    return res.redirect(`/listings/${id}`);
  }

  const diffTime = Math.abs(end - start);
  const nights = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  const guestCount = parseInt(guests) || 1;

  if (guestCount > listing.maxGuests) {
    req.flash("error", `Maximum allowed guests for this property is ${listing.maxGuests}.`);
    return res.redirect(`/listings/${id}`);
  }

  const cleaningFee = 0;
  const serviceFee = 0;
  const totalPrice = listing.price * nights;

  const booking = new Booking({
    listing: listing._id,
    user: req.user._id,
    checkIn: start,
    checkOut: end,
    guests: guestCount,
    nights,
    nightlyPrice: listing.price,
    cleaningFee,
    serviceFee,
    totalPrice,
  });

  await booking.save();
  req.flash("success", `Reservation confirmed for ${nights} night(s) at ${listing.title}! Payment mode: Pay at Property (No online payment required). 100% Free Cancellation available anytime before check-in.`);
  res.redirect("/bookings/trips");
};

module.exports.userBookings = async (req, res) => {
  const bookings = await Booking.find({ user: req.user._id })
    .populate({
      path: "listing",
      populate: { path: "owner" },
    })
    .sort({ createdAt: -1 });

  res.render("bookings/trips.ejs", { bookings });
};

module.exports.hostBookings = async (req, res) => {
  // Find listings owned by this user
  const userListings = await Listing.find({ owner: req.user._id });
  const listingIds = userListings.map((l) => l._id);

  const reservations = await Booking.find({ listing: { $in: listingIds } })
    .populate("listing")
    .populate("user")
    .sort({ createdAt: -1 });

  res.render("bookings/host.ejs", { reservations, listings: userListings });
};

module.exports.cancelBooking = async (req, res) => {
  const { bookingId } = req.params;
  const booking = await Booking.findById(bookingId);

  if (!booking) {
    req.flash("error", "Booking not found.");
    return res.redirect("/bookings/trips");
  }

  if (!booking.user.equals(req.user._id)) {
    req.flash("error", "You do not have permission to cancel this booking.");
    return res.redirect("/bookings/trips");
  }

  booking.status = "Cancelled";
  await booking.save();

  req.flash("success", "Reservation cancelled successfully with 100% Free Cancellation! Zero fees charged.");
  res.redirect("/bookings/trips");
};
