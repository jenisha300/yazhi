const Listing = require("../models/Listing");
const sampleListings = require("../seed/sampleListings");
const mongoose = require("mongoose");

// Helper function to approximate coordinates based on city/country text search
function geocodeLocation(locationStr) {
  const loc = (locationStr || "").toLowerCase();
  
  // Tamil Nadu & Pondicherry
  if (loc.includes("chennai") || loc.includes("marina")) return [80.2707, 13.0827];
  if (loc.includes("ooty") || loc.includes("nilgiris")) return [76.6932, 11.4102];
  if (loc.includes("kodaikanal") || loc.includes("kodai")) return [77.4892, 10.2381];
  if (loc.includes("madurai") || loc.includes("meenakshi")) return [78.1198, 9.9252];
  if (loc.includes("mahabalipuram") || loc.includes("mamallapuram")) return [80.1983, 12.6269];
  if (loc.includes("coonoor")) return [76.7959, 11.3530];
  if (loc.includes("rameswaram")) return [79.3129, 9.2876];
  if (loc.includes("pondicherry") || loc.includes("puducherry") || loc.includes("auroville")) return [79.8083, 11.9416];
  if (loc.includes("munnar")) return [77.0595, 10.0889];
  
  // Mumbai & Maharashtra
  if (loc.includes("mumbai") || loc.includes("bombay") || loc.includes("bandra") || loc.includes("juhu")) return [72.8258, 18.9647];
  if (loc.includes("lonavala") || loc.includes("pune")) return [73.4077, 18.7557];

  // Karnataka & South India
  if (loc.includes("coorg") || loc.includes("kodagu")) return [75.7382, 12.4244];
  if (loc.includes("gokarna") || loc.includes("kudle")) return [74.3188, 14.5479];
  if (loc.includes("wayanad")) return [76.1320, 11.6854];
  if (loc.includes("kochi") || loc.includes("cochin") || loc.includes("fort kochi")) return [76.2673, 9.9312];
  if (loc.includes("mysuru") || loc.includes("mysore")) return [76.6394, 12.2958];
  if (loc.includes("hampi")) return [76.4600, 15.3350];
  if (loc.includes("hyderabad") || loc.includes("charminar")) return [78.4867, 17.3850];

  // Himachal & North India
  if (loc.includes("dharamshala") || loc.includes("mcleod")) return [76.3213, 32.2190];

  // Delhi & NCR
  if (loc.includes("delhi") || loc.includes("hauz khas") || loc.includes("connaught")) return [77.2090, 28.6139];

  // Other India Tourist Hubs
  if (loc.includes("goa") || loc.includes("candolim") || loc.includes("panjim") || loc.includes("anjuna")) return [73.7634, 15.5177];
  if (loc.includes("jaipur") || loc.includes("rajasthan")) return [75.8185, 26.9124];
  if (loc.includes("udaipur")) return [73.6834, 24.5854];
  if (loc.includes("kerala") || loc.includes("alleppey") || loc.includes("kochi") || loc.includes("varkala")) return [76.3388, 9.4981];
  if (loc.includes("manali") || loc.includes("himachal")) return [77.1887, 32.2432];
  if (loc.includes("rishikesh") || loc.includes("uttarakhand")) return [78.3029, 30.0869];
  if (loc.includes("varanasi") || loc.includes("kashi")) return [82.9739, 25.3176];
  if (loc.includes("shimla")) return [77.1734, 31.1048];
  if (loc.includes("darjeeling")) return [88.2636, 27.0410];
  if (loc.includes("agra") || loc.includes("taj")) return [78.0081, 27.1767];
  if (loc.includes("bangalore") || loc.includes("bengaluru")) return [77.5946, 12.9716];
  if (loc.includes("mysuru") || loc.includes("mysore")) return [76.6394, 12.2958];
  if (loc.includes("hampi")) return [76.4600, 15.3350];
  if (loc.includes("hyderabad")) return [78.4867, 17.3850];
  if (loc.includes("shillong") || loc.includes("meghalaya")) return [91.8933, 25.5788];
  if (loc.includes("andaman") || loc.includes("port blair")) return [92.7265, 11.6234];

  // International Destinations
  if (loc.includes("york") || loc.includes("nyc")) return [-74.006, 40.7128];
  if (loc.includes("malibu") || loc.includes("los angeles") || loc.includes("california")) return [-118.7798, 34.0259];
  if (loc.includes("paris") || loc.includes("france")) return [2.3522, 48.8566];
  if (loc.includes("tokyo") || loc.includes("japan")) return [139.6917, 35.6895];
  if (loc.includes("kyoto")) return [135.7681, 35.0116];
  if (loc.includes("london") || loc.includes("uk") || loc.includes("england")) return [-0.1276, 51.5074];
  if (loc.includes("bali") || loc.includes("ubud") || loc.includes("indonesia")) return [115.1889, -8.4095];
  if (loc.includes("rome") || loc.includes("italy")) return [12.4964, 41.9028];
  if (loc.includes("santorini") || loc.includes("greece")) return [25.4317, 36.3932];
  if (loc.includes("miami") || loc.includes("florida")) return [-80.1918, 25.7617];
  if (loc.includes("barcelona") || loc.includes("spain")) return [2.1734, 41.3851];
  if (loc.includes("amsterdam") || loc.includes("netherlands")) return [4.8951, 52.3702];
  if (loc.includes("zurich") || loc.includes("switzerland")) return [8.5417, 47.3769];
  if (loc.includes("dubai") || loc.includes("uae")) return [55.2708, 25.2048];
  if (loc.includes("sydney") || loc.includes("australia")) return [151.2093, -33.8688];
  if (loc.includes("cape town") || loc.includes("south africa")) return [18.4241, -33.9249];

  // Default coordinates (New Delhi)
  return [77.2090, 28.6139];
}

module.exports.index = async (req, res) => {
  const { category, q } = req.query;
  let filter = {};

  if (category) {
    filter.category = category;
  }

  if (q) {
    filter.$or = [
      { title: { $regex: q, $options: "i" } },
      { location: { $regex: q, $options: "i" } },
      { country: { $regex: q, $options: "i" } },
      { description: { $regex: q, $options: "i" } },
    ];
  }

  let allListings = [];
  try {
    if (mongoose.connection.readyState >= 1) {
      allListings = await Listing.find(filter).sort({ createdAt: -1 });
    } else {
      allListings = sampleListings;
    }
  } catch (err) {
    allListings = sampleListings;
  }

  res.render("listings/index.ejs", { allListings, category: category || "", searchQuery: q || "" });
};

module.exports.renderNewForm = (req, res) => {
  res.render("listings/new.ejs");
};

module.exports.createListing = async (req, res) => {
  const { listing } = req.body;
  if (!listing) {
    req.flash("error", "Invalid listing data provided.");
    return res.redirect("/listings/new");
  }

  const coords = geocodeLocation(`${listing.location}, ${listing.country}`);
  
  const newListing = new Listing(listing);
  newListing.owner = req.user._id;
  newListing.geometry = {
    type: "Point",
    coordinates: coords,
  };

  // Image handling
  if (req.file) {
    newListing.image = {
      url: `/uploads/${req.file.filename}`,
      filename: req.file.filename,
    };
  } else if (listing.image && listing.image.url && listing.image.url.trim() !== "") {
    newListing.image = {
      url: listing.image.url.trim(),
      filename: "custom_url",
    };
  } else if (listing.imageUrl && listing.imageUrl.trim() !== "") {
    newListing.image = {
      url: listing.imageUrl.trim(),
      filename: "custom_url",
    };
  } else {
    newListing.image = {
      url: "https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?auto=format&fit=crop&w=1200&q=80",
      filename: "default_property",
    };
  }

  // Parse amenities array if string
  if (typeof listing.amenities === "string") {
    newListing.amenities = listing.amenities.split(",").map((a) => a.trim()).filter(Boolean);
  }

  await newListing.save();
  req.flash("success", "New property listing published successfully!");
  res.redirect(`/listings/${newListing._id}`);
};

module.exports.showListing = async (req, res) => {
  const { id } = req.params;
  let listing = null;

  try {
    if (mongoose.connection.readyState >= 1 && mongoose.Types.ObjectId.isValid(id)) {
      listing = await Listing.findById(id)
        .populate({
          path: "reviews",
          populate: {
            path: "author",
          },
        })
        .populate("owner");
    }
  } catch (err) {
    listing = null;
  }

  // Fallback to sampleListings if DB is not connected or listing is not found in DB
  if (!listing) {
    listing = sampleListings.find(s => s._id && s._id.toString() === id.toString());
  }

  if (!listing) {
    req.flash("error", "Requested stay does not exist!");
    return res.redirect("/listings");
  }

  // Ensure default structure if from sample listings
  if (!listing.reviews) listing.reviews = [];
  if (!listing.owner) {
    listing.owner = {
      username: "rajesh_sharma",
      fullName: "Rajesh Sharma",
      equals: () => false
    };
  } else if (typeof listing.owner.equals !== "function") {
    listing.owner.equals = () => false;
  }

  // Calculate average rating
  let avgRating = 0;
  if (listing.reviews && listing.reviews.length > 0) {
    const total = listing.reviews.reduce((acc, curr) => acc + (curr.rating || 5), 0);
    avgRating = (total / listing.reviews.length).toFixed(1);
  } else {
    avgRating = "4.9";
  }

  res.render("listings/show.ejs", { listing, avgRating });
};

module.exports.renderEditForm = async (req, res) => {
  const { id } = req.params;
  const listing = await Listing.findById(id);
  if (!listing) {
    req.flash("error", "Listing not found!");
    return res.redirect("/listings");
  }
  res.render("listings/edit.ejs", { listing });
};

module.exports.updateListing = async (req, res) => {
  const { id } = req.params;
  const { listing } = req.body;
  
  const updatedListing = await Listing.findByIdAndUpdate(id, { ...listing }, { new: true });

  if (listing.location || listing.country) {
    const coords = geocodeLocation(`${listing.location || updatedListing.location}, ${listing.country || updatedListing.country}`);
    updatedListing.geometry = {
      type: "Point",
      coordinates: coords,
    };
  }

  if (req.file) {
    updatedListing.image = {
      url: `/uploads/${req.file.filename}`,
      filename: req.file.filename,
    };
  } else if (listing.imageUrl && listing.imageUrl.trim() !== "") {
    updatedListing.image = {
      url: listing.imageUrl.trim(),
      filename: "custom_url",
    };
  } else if (listing.image && listing.image.url && listing.image.url.trim() !== "") {
    updatedListing.image = {
      url: listing.image.url.trim(),
      filename: "custom_url",
    };
  }

  if (typeof listing.amenities === "string") {
    updatedListing.amenities = listing.amenities.split(",").map((a) => a.trim()).filter(Boolean);
  }

  await updatedListing.save();
  req.flash("success", "Listing updated successfully!");
  res.redirect(`/listings/${id}`);
};

module.exports.deleteListing = async (req, res) => {
  const { id } = req.params;
  await Listing.findByIdAndDelete(id);
  req.flash("success", "Listing deleted successfully!");
  res.redirect("/listings");
};
