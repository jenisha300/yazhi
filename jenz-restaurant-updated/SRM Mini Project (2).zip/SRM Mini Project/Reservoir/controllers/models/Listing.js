const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const Review = require("./Review");

const listingSchema = new Schema({
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  image: {
    url: {
      type: String,
      default: "https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?auto=format&fit=crop&w=1200&q=80",
    },
    filename: {
      type: String,
      default: "listingimage",
    },
  },
  price: {
    type: Number,
    required: true,
    min: 0,
  },
  location: {
    type: String,
    required: true,
  },
  country: {
    type: String,
    required: true,
  },
  geometry: {
    type: {
      type: String,
      enum: ["Point"],
      default: "Point",
    },
    coordinates: {
      type: [Number], // [longitude, latitude]
      default: [-73.98513, 40.748817],
    },
  },
  category: {
    type: String,
    enum: [
      "Hotels",
      "Beachfront",
      "Cabins",
      "Iconic Cities",
      "Countryside",
      "Lakefront",
      "Pools",
      "Castles",
      "Luxe",
      "Trending",
      "Rooms",
    ],
    default: "Trending",
  },
  bedrooms: {
    type: Number,
    default: 1,
  },
  beds: {
    type: Number,
    default: 1,
  },
  baths: {
    type: Number,
    default: 1,
  },
  maxGuests: {
    type: Number,
    default: 2,
  },
  amenities: {
    type: [String],
    default: ["Fast Wi-Fi", "Dedicated Workspace", "Free Parking", "Air Conditioning"],
  },
  reviews: [
    {
      type: Schema.Types.ObjectId,
      ref: "Review",
    },
  ],
  owner: {
    type: Schema.Types.ObjectId,
    ref: "User",
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

// Middleware to clean up reviews when a listing is deleted
listingSchema.post("findOneAndDelete", async function (listing) {
  if (listing && listing.reviews.length) {
    await Review.deleteMany({ _id: { $in: listing.reviews } });
  }
});

module.exports = mongoose.model("Listing", listingSchema);
