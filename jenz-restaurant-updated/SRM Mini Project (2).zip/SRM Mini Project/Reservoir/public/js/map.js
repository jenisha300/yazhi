// Mapbox / Leaflet Interactive Location Mapping for Reservoir
document.addEventListener("DOMContentLoaded", () => {
  // 1. Custom Red Reservoir Pin Icon
  const reservoirIcon = L.divIcon({
    className: "custom-map-marker",
    html: `<div style="background-color: #ff385c; color: white; width: 38px; height: 38px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 14px rgba(255,56,92,0.4); border: 2px solid white; transform: scale(1); transition: transform 0.2s ease;"><i class="fa-solid fa-house-chimney" style="font-size: 16px;"></i></div>`,
    iconSize: [38, 38],
    iconAnchor: [19, 38],
    popupAnchor: [0, -38],
  });

  // 2. Single Listing Detail Page Location Map
  const singleMapContainer = document.getElementById("singleMap");
  if (singleMapContainer && typeof singleListingData !== "undefined" && singleListingData.geometry) {
    const coords = singleListingData.geometry.coordinates; // [lng, lat]
    const latLng = [coords[1], coords[0]]; // Leaflet uses [lat, lng]

    const map = L.map("singleMap", {
      scrollWheelZoom: false,
      zoomControl: true,
    }).setView(latLng, 13);

    // OpenStreetMap High Definition Tile Layer
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: '© OpenStreetMap contributors | Reservoir Location Mapping',
    }).addTo(map);

    // Add Circle radius overlay representing neighbourhood zone
    L.circle(latLng, {
      color: "#ff385c",
      fillColor: "#ff385c",
      fillOpacity: 0.12,
      radius: 600,
    }).addTo(map);

    const marker = L.marker(latLng, { icon: reservoirIcon }).addTo(map);

    const popupContent = `
      <div style="font-family: sans-serif; padding: 6px; max-width: 220px;">
        <h6 style="font-weight: 700; margin-bottom: 4px; color: #222;">${singleListingData.title}</h6>
        <p style="margin: 0; font-size: 0.85rem; color: #555;"><i class="fa-solid fa-location-dot" style="color: #ff385c;"></i> ${singleListingData.location}, ${singleListingData.country}</p>
        <strong style="color: #ff385c; font-size: 1rem; display: block; margin-top: 6px;">₹${singleListingData.price.toLocaleString("en-IN")} / night</strong>
        <a href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(singleListingData.location + ', ' + singleListingData.country)}" target="_blank" style="display: inline-block; margin-top: 6px; font-size: 0.8rem; font-weight: 700; color: #000; text-decoration: underline;">Open in Google Maps</a>
      </div>
    `;

    marker.bindPopup(popupContent).openPopup();
  }

  // 3. Overview Modal Map with All Properties Pins
  const overviewMapModal = document.getElementById("mapOverviewModal");
  const mapToggleBtn = document.getElementById("mapToggleBtn");
  let overviewMap = null;

  function initOrUpdateOverviewMap() {
    const mapDiv = document.getElementById("overviewMap");
    if (!mapDiv) return;

    if (!overviewMap) {
      overviewMap = L.map("overviewMap").setView([20.5937, 78.9629], 5); // Default India Centered

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 18,
        attribution: '© OpenStreetMap contributors | Reservoir Location Mapping',
      }).addTo(overviewMap);

      if (typeof listingsMapData !== "undefined" && listingsMapData.length > 0) {
        const bounds = [];

        listingsMapData.forEach((item) => {
          if (item.geometry && item.geometry.coordinates) {
            const coords = item.geometry.coordinates;
            const latLng = [coords[1], coords[0]];
            bounds.push(latLng);

            const priceTagIcon = L.divIcon({
              className: "price-tag-marker",
              html: `<div style="background-color: white; color: #222; padding: 6px 12px; border-radius: 20px; font-weight: 800; font-size: 13px; box-shadow: 0 4px 14px rgba(0,0,0,0.25); border: 1.5px solid #ddd; white-space: nowrap;">₹${item.price.toLocaleString('en-IN')}</div>`,
              iconSize: [85, 30],
              iconAnchor: [42, 15],
            });

            const m = L.marker(latLng, { icon: priceTagIcon }).addTo(overviewMap);

            const popHtml = `
              <div style="font-family: sans-serif; max-width: 210px;">
                <img src="${item.image.url}" style="width: 100%; height: 110px; object-fit: cover; border-radius: 8px; margin-bottom: 6px;">
                <h6 style="font-weight: 700; margin: 0 0 2px 0; font-size: 0.9rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${item.title}</h6>
                <p style="margin: 0; font-size: 0.8rem; color: #666;"><i class="fa-solid fa-location-dot" style="color: #ff385c;"></i> ${item.location}</p>
                <div style="margin-top: 8px; display: flex; justify-content: space-between; align-items: center;">
                  <strong style="color: #ff385c;">₹${item.price.toLocaleString('en-IN')} <span style="font-weight: normal; color: #555; font-size: 0.8rem;">night</span></strong>
                  <a href="/listings/${item._id}" style="font-size: 0.8rem; text-decoration: underline; font-weight: 700; color: #000;">View Stay</a>
                </div>
              </div>
            `;

            m.bindPopup(popHtml);
          }
        });

        if (bounds.length > 0) {
          overviewMap.fitBounds(bounds, { padding: [50, 50] });
        }
      }
    }

    setTimeout(() => {
      if (overviewMap) {
        overviewMap.invalidateSize();
      }
    }, 300);
  }

  if (overviewMapModal) {
    overviewMapModal.addEventListener("shown.bs.modal", initOrUpdateOverviewMap);
  }

  if (mapToggleBtn) {
    mapToggleBtn.addEventListener("click", () => {
      setTimeout(initOrUpdateOverviewMap, 400);
    });
  }
});
