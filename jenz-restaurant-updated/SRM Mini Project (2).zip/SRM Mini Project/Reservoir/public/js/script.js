// Client-side script for Reservoir
document.addEventListener("DOMContentLoaded", () => {
  // 1. Bootstrap Form Validation
  const forms = document.querySelectorAll(".needs-validation");
  Array.from(forms).forEach((form) => {
    form.addEventListener(
      "submit",
      (event) => {
        if (!form.checkValidity()) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add("was-validated");
      },
      false
    );
  });

  // 2. Wishlist Heart Button Toggle
  const wishlistBtns = document.querySelectorAll(".wishlist-btn");
  wishlistBtns.forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      btn.classList.toggle("active");
      const icon = btn.querySelector(".heart-icon");
      if (icon) {
        if (btn.classList.contains("active")) {
          icon.classList.remove("fa-regular");
          icon.classList.add("fa-solid");
        } else {
          icon.classList.remove("fa-solid");
          icon.classList.add("fa-regular");
        }
      }
    });
  });

  // Guest Counter Buttons for Search Modal
  const guestMinusBtn = document.getElementById("guestMinusBtn");
  const guestPlusBtn = document.getElementById("guestPlusBtn");
  const guestCountDisplay = document.getElementById("guestCountDisplay");
  let currentGuestCount = 1;

  if (guestMinusBtn && guestPlusBtn && guestCountDisplay) {
    guestMinusBtn.addEventListener("click", () => {
      if (currentGuestCount > 1) {
        currentGuestCount--;
        guestCountDisplay.textContent = currentGuestCount;
      }
    });

    guestPlusBtn.addEventListener("click", () => {
      if (currentGuestCount < 16) {
        currentGuestCount++;
        guestCountDisplay.textContent = currentGuestCount;
      }
    });
  }

  // 3. Tax Display Switch
  const taxSwitch = document.getElementById("flexSwitchCheckDefault");
  if (taxSwitch) {
    taxSwitch.addEventListener("click", () => {
      const taxInfos = document.querySelectorAll(".tax-info");
      const basePrices = document.querySelectorAll(".base-price");

      taxInfos.forEach((info) => {
        info.classList.toggle("d-none");
      });

      basePrices.forEach((priceEl) => {
        const rawPrice = parseFloat(priceEl.getAttribute("data-price"));
        if (taxSwitch.checked) {
          const totalWithTax = Math.round(rawPrice * 1.18);
          priceEl.textContent = `₹${totalWithTax.toLocaleString("en-IN")}`;
        } else {
          priceEl.textContent = `₹${rawPrice.toLocaleString("en-IN")}`;
        }
      });
    });
  }

  // 4. Booking Card Nightly Price & Total Calculator
  const checkInInput = document.getElementById("checkIn");
  const checkOutInput = document.getElementById("checkOut");
  const numNightsSpan = document.getElementById("numNights");
  const calcSubtotalSpan = document.getElementById("calcSubtotal");
  const calcServiceFeeSpan = document.getElementById("calcServiceFee");
  const calcTotalSpan = document.getElementById("calcTotal");
  const priceEl = document.getElementById("displayNightlyPrice");

  if (checkInInput && checkOutInput && priceEl) {
    const nightlyRate = parseFloat(priceEl.getAttribute("data-price"));

    // Set min date to today for check-in
    const today = new Date().toISOString().split("T")[0];
    checkInInput.min = today;

    // Default dates (Tomorrow to 3 days after)
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const threeDaysLater = new Date();
    threeDaysLater.setDate(threeDaysLater.getDate() + 4);

    checkInInput.value = tomorrow.toISOString().split("T")[0];
    checkOutInput.min = tomorrow.toISOString().split("T")[0];
    checkOutInput.value = threeDaysLater.toISOString().split("T")[0];

    function calculateBookingPrice() {
      const start = new Date(checkInInput.value);
      const end = new Date(checkOutInput.value);

      if (start && end && end > start) {
        const diffTime = Math.abs(end - start);
        const nights = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        const subtotal = nightlyRate * nights;

        if (numNightsSpan) numNightsSpan.textContent = nights;
        if (calcSubtotalSpan) calcSubtotalSpan.textContent = `₹${subtotal.toLocaleString("en-IN")}`;
        if (calcTotalSpan) calcTotalSpan.textContent = `₹${subtotal.toLocaleString("en-IN")}`;
      }
    }

    checkInInput.addEventListener("change", () => {
      checkOutInput.min = checkInInput.value;
      if (new Date(checkOutInput.value) <= new Date(checkInInput.value)) {
        const nextDay = new Date(checkInInput.value);
        nextDay.setDate(nextDay.getDate() + 1);
        checkOutInput.value = nextDay.toISOString().split("T")[0];
      }
      calculateBookingPrice();
    });

    checkOutInput.addEventListener("change", calculateBookingPrice);

    // Initial calculation
    calculateBookingPrice();
  }
});
