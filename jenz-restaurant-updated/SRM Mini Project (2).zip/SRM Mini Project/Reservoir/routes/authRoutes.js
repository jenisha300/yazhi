const express = require("express");
const router = express.Router();
const passport = require("passport");
const authController = require("../controllers/authController");
const { saveRedirectUrl, isLoggedIn } = require("../middleware/authMiddleware");
const multer = require("multer");
const upload = multer({ dest: "public/uploads/" });

const mongoose = require("mongoose");

router
  .route("/register")
  .get(authController.renderRegister)
  .post(upload.single("avatar"), saveRedirectUrl, (req, res, next) => {
    if (mongoose.connection.readyState < 1) {
      req.flash("error", "Database connection is offline. Registration requires an active database.");
      return res.redirect("/register");
    }
    authController.register(req, res, next);
  });

router
  .route("/login")
  .get(authController.renderLogin)
  .post(saveRedirectUrl, (req, res, next) => {
    if (mongoose.connection.readyState < 1) {
      req.flash("error", "Database connection is offline. If running locally, please start MongoDB (net start MongoDB).");
      return res.redirect("/login");
    }
    passport.authenticate("local", (err, user, info) => {
      if (err) {
        req.flash("error", err.message || "Database connection error. Please try again.");
        return res.redirect("/login");
      }
      if (!user) {
        req.flash("error", info && info.message ? info.message : "Invalid username/email or password.");
        return res.redirect("/login");
      }
      req.login(user, (loginErr) => {
        if (loginErr) return next(loginErr);
        return authController.login(req, res, next);
      });
    })(req, res, next);
  });

router.get("/logout", authController.logout);

router
  .route("/profile")
  .get(isLoggedIn, authController.renderProfile)
  .post(isLoggedIn, upload.single("avatar"), authController.updateProfile);

router.get("/favorites", isLoggedIn, authController.renderFavorites);
router.post("/favorites/:id/toggle", isLoggedIn, authController.toggleFavorite);

module.exports = router;


