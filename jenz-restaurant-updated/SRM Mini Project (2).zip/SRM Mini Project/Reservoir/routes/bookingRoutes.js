const express = require("express");
const router = express.Router();
const bookingsController = require("../controllers/bookingsController");
const { isLoggedIn } = require("../middleware/authMiddleware");

router.post("/listings/:id/book", isLoggedIn, bookingsController.createBooking);
router.get("/trips", isLoggedIn, bookingsController.userBookings);
router.get("/host", isLoggedIn, bookingsController.hostBookings);
router.post("/:bookingId/cancel", isLoggedIn, bookingsController.cancelBooking);

module.exports = router;
