const express = require("express");
const router = express.Router();
const listingsController = require("../controllers/listingsController");
const { isLoggedIn, isOwner } = require("../middleware/authMiddleware");
const multer = require("multer");
const upload = multer({ dest: "public/uploads/" });

router
  .route("/")
  .get(listingsController.index)
  .post(isLoggedIn, upload.single("image"), listingsController.createListing);

router.get("/new", isLoggedIn, listingsController.renderNewForm);

router
  .route("/:id")
  .get(listingsController.showListing)
  .put(isLoggedIn, isOwner, upload.single("image"), listingsController.updateListing)
  .delete(isLoggedIn, isOwner, listingsController.deleteListing);

router.get("/:id/edit", isLoggedIn, isOwner, listingsController.renderEditForm);

module.exports = router;
