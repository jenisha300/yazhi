const express = require("express");
const router = express.Router({ mergeParams: true });
const reviewsController = require("../controllers/reviewsController");
const { isLoggedIn, isReviewAuthor } = require("../middleware/authMiddleware");

router.post("/", isLoggedIn, reviewsController.createReview);

router.delete("/:reviewId", isLoggedIn, isReviewAuthor, reviewsController.deleteReview);

module.exports = router;
