const mongoose = require("mongoose");
const Listing = require("../models/Listing");
const User = require("../models/User");
const Review = require("../models/Review");
const sampleListings = require("./sampleListings");

const MONGO_URL = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/reservoir";

async function main() {
  await mongoose.connect(MONGO_URL);
  console.log("Connected to MongoDB database for seeding.");
}

const indianUserData = [
  { username: "aarav_sharma", email: "aarav.sharma@reservoir.com", fullName: "Aarav Sharma", avatar: "" },
  { username: "priya_iyer", email: "priya.iyer@reservoir.com", fullName: "Priya Ananthakrishnan", avatar: "" },
  { username: "rohan_verma", email: "rohan.verma@reservoir.com", fullName: "Rohan Verma", avatar: "" },
  { username: "kavya_nair", email: "kavya.nair@reservoir.com", fullName: "Kavya Nair", avatar: "" },
  { username: "vikram_patel", email: "vikram.patel@reservoir.com", fullName: "Vikram Patel", avatar: "" },
  { username: "sneha_reddy", email: "sneha.reddy@reservoir.com", fullName: "Sneha Reddy", avatar: "" },
  { username: "karthik_sundaram", email: "karthik.sundaram@reservoir.com", fullName: "Karthik Sundaram", avatar: "" },
  { username: "ananya_deshmukh", email: "ananya.d@reservoir.com", fullName: "Ananya Deshmukh", avatar: "" },
  { username: "rahul_banerjee", email: "rahul.banerjee@reservoir.com", fullName: "Rahul Banerjee", avatar: "" },
  { username: "meera_kulkarni", email: "meera.kulkarni@reservoir.com", fullName: "Meera Kulkarni", avatar: "" },
  { username: "aditya_kapoor", email: "aditya.kapoor@reservoir.com", fullName: "Aditya Kapoor", avatar: "" },
  { username: "divya_menon", email: "divya.menon@reservoir.com", fullName: "Divya Menon", avatar: "" },
];

const indianReviewsList = [
  { comment: "Absolute perfection! The photos don't even do justice to how incredible this stay is. High-speed Wi-Fi and delicious morning breakfast!", rating: 5 },
  { comment: "Immaculate cleanliness, smooth check-in, and very hospitable hosts. We enjoyed our family weekend stay thoroughly!", rating: 5 },
  { comment: "Breathtaking views and peaceful atmosphere! The authentic local filter coffee served in the morning made our trip memorable.", rating: 5 },
  { comment: "Super comfortable rooms, tasteful interior design, and great location close to key travel hubs. Highly recommended!", rating: 5 },
  { comment: "Wonderful stay experience! The host was extremely polite and helpful with local travel tips. Great value for money.", rating: 4 },
  { comment: "Lovely property with beautiful surrounding greenery and complete privacy. The pool area was clean and well maintained.", rating: 5 },
  { comment: "Exceeded all our expectations! Clean linens, quiet surroundings, and prompt support whenever requested.", rating: 5 },
  { comment: "Perfect spot for a relaxing vacation with family! Accessible location and very cozy, modern ambiance.", rating: 4 },
  { comment: "Top-notch Indian hospitality! The room was spacious and the scenic balcony views were unmatched.", rating: 5 },
  { comment: "Very spacious property with excellent amenities. Clean bathrooms and peaceful, quiet nights.", rating: 5 },
];

async function seedDB() {
  try {
    await main();

    // Clear existing data
    await Listing.deleteMany({});
    await User.deleteMany({});
    await Review.deleteMany({});

    // Create a demo host user with Indian name
    const demoUser = new User({
      username: "rajesh_sharma",
      email: "rajesh@reservoir.com",
      fullName: "Rajesh Sharma",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80",
      isHost: true,
    });

    const registeredHost = await User.register(demoUser, "password123");
    console.log("Created demo host user: rajesh_sharma / password123");

    // Register all Indian reviewer users
    const registeredReviewers = [];
    for (let uData of indianUserData) {
      const u = new User({
        username: uData.username,
        email: uData.email,
        fullName: uData.fullName,
        avatar: uData.avatar,
        isHost: false,
      });
      const regU = await User.register(u, "password123");
      registeredReviewers.push(regU);
    }
    console.log(`Created ${registeredReviewers.length} Indian customer accounts.`);

    // Insert sample listings attached to the host, with reviews from Indian customers
    let listingIndex = 0;
    for (let listingData of sampleListings) {
      const listing = new Listing({
        ...listingData,
        owner: registeredHost._id,
      });

      // Pick 2-3 distinct Indian reviewer users for this listing
      const reviewer1 = registeredReviewers[listingIndex % registeredReviewers.length];
      const reviewer2 = registeredReviewers[(listingIndex + 1) % registeredReviewers.length];
      const reviewer3 = registeredReviewers[(listingIndex + 4) % registeredReviewers.length];

      const r1Data = indianReviewsList[listingIndex % indianReviewsList.length];
      const r2Data = indianReviewsList[(listingIndex + 3) % indianReviewsList.length];
      const r3Data = indianReviewsList[(listingIndex + 6) % indianReviewsList.length];

      const review1 = new Review({
        comment: r1Data.comment,
        rating: r1Data.rating,
        author: reviewer1._id,
      });
      const review2 = new Review({
        comment: r2Data.comment,
        rating: r2Data.rating,
        author: reviewer2._id,
      });
      const review3 = new Review({
        comment: r3Data.comment,
        rating: r3Data.rating,
        author: reviewer3._id,
      });

      await review1.save();
      await review2.save();
      await review3.save();

      listing.reviews.push(review1._id, review2._id, review3._id);
      await listing.save();
      listingIndex++;
    }

    console.log(`Successfully seeded ${sampleListings.length} listings with Indian customer reviews!`);
  } catch (err) {
    console.error("Error seeding database:", err);
  } finally {
    await mongoose.connection.close();
    console.log("Database connection closed.");
  }
}

seedDB();

