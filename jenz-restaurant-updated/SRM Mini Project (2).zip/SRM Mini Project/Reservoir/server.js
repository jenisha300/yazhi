if (process.env.NODE_ENV !== "production") {
  require("dotenv").config();
}

const express = require("express");
const app = express();
const mongoose = require("mongoose");
const path = require("path");
const methodOverride = require("method-override");
const ejsMate = require("ejs-mate");
const session = require("express-session");
const flash = require("connect-flash");
const passport = require("passport");
const LocalStrategy = require("passport-local");

const User = require("./models/User");

// Import Routes
const listingRoutes = require("./routes/listingRoutes");
const reviewRoutes = require("./routes/reviewRoutes");
const bookingRoutes = require("./routes/bookingRoutes");
const authRoutes = require("./routes/authRoutes");

// Database Connection
const MONGO_URL = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/reservoir";

async function connectDB() {
  if (mongoose.connection.readyState >= 1) return;
  if (process.env.VERCEL && !process.env.MONGODB_URI) {
    console.log("Vercel environment: MONGODB_URI not provided, running in static sample mode.");
    return;
  }
  try {
    await mongoose.connect(MONGO_URL, {
      serverSelectionTimeoutMS: 2000,
    });
    console.log("Connected to MongoDB Database successfully.");
  } catch (err) {
    console.error("MongoDB Connection Warning:", err.message);
  }
}

connectDB();

// Middleware to ensure DB connection on serverless requests
app.use(async (req, res, next) => {
  await connectDB();
  next();
});

// View Engine Setup
app.engine("ejs", ejsMate);
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(methodOverride("_method"));
app.use(express.static(path.join(__dirname, "public")));

// Session Configuration
const sessionOptions = {
  secret: process.env.SESSION_SECRET || "reservoirspersecretkey12345",
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    httpOnly: true,
  },
};

app.use(session(sessionOptions));
app.use(flash());

// Disable command buffering so operations fail fast if DB is disconnected
mongoose.set("bufferCommands", false);

// Passport Authentication Middleware
app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStrategy(User.authenticate()));

passport.serializeUser(User.serializeUser());
passport.deserializeUser((id, done) => {
  if (mongoose.connection.readyState < 1) {
    return done(null, null);
  }
  User.deserializeUser()(id, done);
});

// Global Locals Middleware
app.use((req, res, next) => {
  res.locals.success = req.flash("success");
  res.locals.error = req.flash("error");
  res.locals.currentUser = req.user;
  next();
});

// Root Route
app.get("/", (req, res) => {
  res.redirect("/listings");
});

// Mount Routes
app.use("/listings", listingRoutes);
app.use("/listings/:id/reviews", reviewRoutes);
app.use("/bookings", bookingRoutes);
app.use("/", authRoutes);

// 404 Route Handler
app.all("*", (req, res, next) => {
  res.status(404).render("error.ejs", { err: { message: "Page Not Found (404)" } });
});

// Global Error Handler
app.use((err, req, res, next) => {
  const { statusCode = 500, message = "Something went wrong!" } = err;
  res.status(statusCode).render("error.ejs", { err: { message } });
});

if (process.env.NODE_ENV !== "test" && !process.env.VERCEL) {
  const PORT = process.env.PORT || 8080;
  app.listen(PORT, () => {
    console.log(`Reservoir server is running on http://localhost:${PORT}`);
  });
}

module.exports = app;
